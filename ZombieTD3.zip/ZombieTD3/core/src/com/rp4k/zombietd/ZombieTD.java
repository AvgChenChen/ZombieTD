package com.rp4k.zombietd;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Intersector;
import com.badlogic.gdx.math.Vector3;

import java.util.ArrayList;
import java.util.Random;

public class ZombieTD extends ApplicationAdapter {
	SpriteBatch batch;
	public OrthographicCamera camera;
	public static ArrayList<Cannon> cannonList = new ArrayList<Cannon>();
    public static ArrayList<Zombie> zombieList = new ArrayList<Zombie>();
	public static ArrayList<Bullet> bulletList = new ArrayList<Bullet>();
	public static ArrayList<Explosion> explosionList = new ArrayList<Explosion>();
	public static ArrayList<Button> buttonList = new ArrayList<Button>();
	public static ArrayList<Wall> wallList = new ArrayList<Wall>();
	public static String currentType = "cannon";

	@Override
	public void create () {
		batch = new SpriteBatch();
		camera = new OrthographicCamera();
		camera.setToOrtho(false,1024,600);
		buttonList.add(new Button("wall", Resources.wallIcon, 100, 525));
		buttonList.add(new Button("mounted", Resources.mountedCannonIcon, 200,525));
		buttonList.add(new Button("cannon", Resources.cannonIcon, 300, 525));
		buttonList.add(new Button("fire", Resources.fireCannonIcon, 400, 525));
		buttonList.add(new Button("super", Resources.superCannonIcon, 500, 525));
		buttonList.add(new Button("beam", Resources.beamCannonIcon, 600, 525));
		buttonList.add(new Button("crab", Resources.crabCannonIcon, 700, 525));
		buttonList.add(new Button("double",Resources.doubleCannonIcon,800,525));
	}

	@Override
	public void render () {
		Gdx.gl.glClearColor(1, 10, 0, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		update();
		camera.update();
		batch.setProjectionMatrix(camera.combined);
		batch.begin();
		batch.draw(Resources.dgTexture, 0, 0);

		for(Wall w : wallList){
			w.draw(batch);
		}

		for (int i = 0; i < cannonList.size(); i++){
		    cannonList.get(i).draw(batch);
        }
        for (int i = 0; i < zombieList.size(); i++){
        	if(zombieList.get(i).active) {
				zombieList.get(i).draw(batch);
			}
        }
		for (int i = 0; i < bulletList.size(); i++){
			if(bulletList.get(i).active) {
				bulletList.get(i).draw(batch);
			}
		}



		for(Explosion e : explosionList){
			e.draw(batch);
		}

		for(Button b : buttonList){
			b.draw(batch);
		}



		UI.draw(batch);
		batch.end();
	}

	public void update(){
		controls();
		if(UI.life > 0){
			spawnZombies();
			checkCollision();
			checkWall();
			for(Cannon c : cannonList){
				c.update();
			}

			for(Zombie z : zombieList){
				z.update();
			}

			for(Bullet b : bulletList){
				b.update();
			}

			for(Explosion e : explosionList){
				e.update();
			}

			removeSprites();
		}
    }
	
	@Override
	public void dispose () {
		batch.dispose();
	}

	public void controls(){
		if(Gdx.input.justTouched()){
			Vector3 touchPos = new Vector3();
			touchPos.set(Gdx.input.getX(),Gdx.input.getY(),0);
			camera.unproject(touchPos);
			int x = (int)touchPos.x;
			int y = (int)touchPos.y;

			for(Button b : buttonList)
				if(b.getRectangle().contains(x, y)) {
					switch(b.type){
						case "fire":
						case "super":
							if(!b.locked){
								clearSection();
								b.selected = true;
								currentType = b.type;
							} else if(b.locked && UI.money >= 300) {
								UI.money -= 400;
								b.locked = false;
							}
							break;
						case "beam":
						case "crab":
						case "double":
							if(!b.locked){
								clearSection();
								b.selected = true;
								currentType = b.type;
							} else if(b.locked && UI.money >= 500) {
								UI.money -= 600;
								b.locked = false;
							}
							break;
						case "cannon":
							clearSection();
							b.selected = true;
							currentType = b.type;
							break;
						case "wall":
							if(wallList.size() < 6 && UI.money > 100){
								UI.money -= 300;
								wallList.add(new Wall(wallList.size() * 50, 0));
							}
							break;
						case "mounted":
							if(!b.locked && wallList.size() < 3 && UI.money > 200){
								Wall w = new Wall(wallList.size() * 50, 0);
								wallList.add(w);
								for(int i = 0; i < w.wallTexture.getHeight() / 50; i++)
									cannonList.add(new Cannon(Resources.mountedCannon,"mounted", w.xPos, w.yPos + i * 50,1,1));
							} else if (b.locked && UI.money >= 5000){
								UI.money -= 2000;
								b.locked = false;
							}
							break;
						case "playagain":
							resetGame();
							break;
					}
				}

			for(int i = 0; i < cannonList.size(); i++) {
				if (cannonList.get(i).getRectangle().contains(x, y)) {
					return;
				}
			}

			if(isBuildable(y) && UI.money >= 20) {
					cannonList.add(new Cannon(Resources.cannon, currentType, x, y, 3, 3));

			}
		}
	}

    public void clearSection(){
		for(Button b: buttonList){
			b.selected = false;
		}

	}
    public void spawnZombies(){
		if(zombieList.isEmpty()) {
			UI.wave++;
			UI.msg = true;
			Random r = new Random();
			for (int i = 0; i < 5 * UI.wave; i++) {
				int y = r.nextInt(400) + 50;
				if (i % 15 == 0)
					zombieList.add(new Zombie(Resources.rtx3080, 1024 + i * 50, y, 3, 5, 1, 1,3));
				else
					zombieList.add(new Zombie(Resources.bill, 1024 + i * 150, y + 90, 2, 6, 2, 3,3));



			}
		}
    }

    public void removeSprites(){
		for(int i = 0; i < zombieList.size(); i++){
			if(!zombieList.get(i).active){
				zombieList.remove(i);
			}
		}

		for(int i = 0; i < bulletList.size(); i++){
			if(!bulletList.get(i).active){
				bulletList.remove(i);
			}
		}

		for(int i = 0; i < explosionList.size(); i++){
			if(!explosionList.get(i).active){
				explosionList.remove(i);
			}
		}

		for(int i = 0; i < wallList.size(); i++){
			if(!wallList.get(i).active){
				wallList.remove(i);
			}
		}
	}

	public void checkCollision(){
		if(!zombieList.isEmpty() && !bulletList.isEmpty()){
			for(int i = 0; i < zombieList.size(); i++){
				for(int j = 0; j < bulletList.size(); j++){
					if(Intersector.overlaps(bulletList.get(j).getCircle(), zombieList.get(i).getRectangle()))
					{
						explosionList.add(new Explosion(Resources.basicExplosion, zombieList.get(i).xPos + 25, zombieList.get(i).yPos, 6, 1));
						zombieList.get(i).takeDamage();
						bulletList.get(j).active = false;
					}
				}
			}
		}
	}

	public void checkWall(){
		if(!zombieList.isEmpty() && !wallList.isEmpty()){
			for(int i = 0; i < zombieList.size(); i++){
				for(int j = 0; j < wallList.size(); j++){
					if(Intersector.overlaps(wallList.get(j).getRectangle(), zombieList.get(i).getRectangle())){
						explosionList.add(new Explosion(Resources.basicExplosion, zombieList.get(i).xPos + 25, zombieList.get(i).yPos, 6, 1));
						zombieList.get(i).active = false;
						wallList.get(j).takeDamage(1);
					}
				}
			}
		}
	}

	public boolean isBuildable(float y){
		return (y <= 200 && y >= 0) || (y >= 300 && y <= 500);
	}

	public void resetGame(){
		//Clear all lists
		cannonList.clear();
		zombieList.clear();
		buttonList.clear();
		bulletList.clear();
		wallList.clear();

		//Reset UI elements
		UI.money = 10000;
		UI.life = 100;
		UI.wave = 0;

		//Buttons
		buttonList.add(new Button("wall", Resources.wallIcon, 100, 525));
		buttonList.add(new Button("mounted", Resources.mountedCannonIcon, 200,525));
		buttonList.add(new Button("cannon", Resources.cannonIcon, 300, 525));
		buttonList.add(new Button("fire", Resources.fireCannonIcon, 400, 525));
		buttonList.add(new Button("super", Resources.superCannonIcon, 500, 525));
		buttonList.add(new Button("beam", Resources.beamCannonIcon, 600, 525));
		buttonList.add(new Button("crab", Resources.crabCannonIcon, 700, 525));
		buttonList.add(new Button("double",Resources.doubleCannonIcon,800,525));
	}

}