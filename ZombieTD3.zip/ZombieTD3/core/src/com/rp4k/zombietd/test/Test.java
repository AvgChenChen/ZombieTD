package com.rp4k.zombietd.test;

import com.rp4k.zombietd.Button;

import java.util.ArrayList;

public class Test {
    public class User{
        String fName;
        String lName;
        int id;
        public User(String fName, String lName, int id){
            this.fName = fName;
            this.lName = lName;
            this.id = id;
        }
    }

    public static class Account{
        Double balance;
        User user;
        int id;
        public Account(User user, double balance, int id){
            this.user = user;
            this.balance = balance;
            this.id = id;
        }
    }
    public static class AccountManager{
        ArrayList<Account> accountList = new ArrayList<>();

        // TODO: IMPLEMENT AN ADDACCOUNT METHOD [ACCOUNTS SHOULD BE UNIQUE]
        public void addAccount(Account a){
            for(Account b : accountList){
               if(a.id == b.id){
                   System.out.println("ERROR Account Already Exist");
                   return;
               }
            }
            accountList.add(a);
            System.out.println("Account Added");
        }
        // TODO: IMPLEMENT A DEPOSIT METHOD [DEPOSITS SHOULD FIND THE ACCOUNT AND DEPOSIT AN AMOUNT]
        public void depositAmount(int targetId, int amount) {}
        // TODO: IMPLEMENT A WITHDRAW METHOD [WITHDRAW SHOULD FIND THE ACCOUNT AND WITHDRAW AN AMOUNT IF THE AMOUNT DOES NOT EXCEED THE ACCOUNT BALANCE]
        public void withdrawAmount(int targetId, int amount) {}
        // TODO: IMPLEMENT A GETACCOUNTBALANCE METHOD [SHOULD FIND THE ACCOUT AND RETURN THE BALANCE]
        public Double getAccountBalance(int targetId) {505f}

    }

    public static void main(String[] args) {
        AccountManager am = new AccountManager();
    }
}
