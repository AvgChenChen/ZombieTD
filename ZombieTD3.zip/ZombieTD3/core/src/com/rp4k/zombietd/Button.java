package com.rp4k.zombietd;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;

public class Button {
    public float xPos, yPos, width, height;
    public Texture buttonTexure;
    public String type = "default";
    public boolean locked = false;
    public boolean selected = false;

    public Button(String type, Texture btex, float x, float y){
        this.type = type;
        switch(type){
            case "fire":
            case "super":
            case "beam":
            case "crab":
            case "mounted":
            case "double":
                locked = true;
                break;
            case "cannon":
                selected = true;
                locked = false;
                break;
            default:
                break;
        }
        buttonTexure = btex;
        xPos = x;
        yPos = y;
        width = buttonTexure.getWidth();
        height = buttonTexure.getHeight();
    }

    public void draw(SpriteBatch batch){
        batch.draw(buttonTexure, xPos, yPos);
        if(locked)
            batch.draw(Resources.locked,xPos,yPos);
        if(selected)
            batch.draw(Resources.border, xPos - 7f, yPos - 7f);
    }

    public Rectangle getRectangle(){
        return new Rectangle(xPos, yPos, width, height);
    }
}
