package com.rp4k.zombietd;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Circle;

import java.util.Arrays;

public class Bullet {
    public Texture bulletTexture;
    public float xPos, yPos, width, height, speed, angle;
    public boolean active;
    public int life;
    public int damage = 1;

    public Bullet(Texture btex,float x, float y){
        bulletTexture = btex;
        xPos = x;
        yPos = y;
        width = bulletTexture.getWidth();
        height = bulletTexture.getHeight();
        speed = 5;
        active = true;
        angle = 0;
        getAngle();
        life = 100;
    }

    public void draw(SpriteBatch batch){

        batch.draw(bulletTexture, xPos - width / 2, yPos - height /2);
    }

    public void update(){
        xPos += (float)Math.cos(angle) * speed;
        yPos += (float)Math.sin(angle) * speed;
        if(life-- < 0){
            active = false;
        }
    }

    public void getAngle(){
        if(!ZombieTD.zombieList.isEmpty()){
            float[] da = new float[ZombieTD.zombieList.size()]; // difference array
            for(int i = 0; i < ZombieTD.zombieList.size(); i++){
                da[i] = Math.abs(xPos - ZombieTD.zombieList.get(i).xPos) + Math.abs(yPos - ZombieTD.zombieList.get(i).yPos);
            }
            Arrays.sort(da);
            float xZ, yZ, angle;
            xZ = 0;
            yZ = 0;

            for(int i = 0; i < ZombieTD.zombieList.size(); i++){
                if(da[0] == Math.abs(xPos - ZombieTD.zombieList.get(i).xPos) + Math.abs(yPos - ZombieTD.zombieList.get(i).yPos)){
                    xZ = ZombieTD.zombieList.get(i).xPos;
                    yZ = ZombieTD.zombieList.get(i).yPos;
                }
            }

            angle = (float) Math.atan((yPos - yZ) / (xPos - xZ));
            if(xPos >= xZ)
                angle += Math.PI;
            this.angle = angle;
        }
    }

    public Circle getCircle(){
        return new Circle(xPos, yPos, width / 2);
    }



}


