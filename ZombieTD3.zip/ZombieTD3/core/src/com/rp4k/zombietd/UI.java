package com.rp4k.zombietd;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class UI {
    public static int money = 5000;
    public static int wave = 0;
    public static int life = 100;
    public static int counter = 0;
    public static boolean msg = false;
    public static BitmapFont font = new BitmapFont();

    public static void draw(SpriteBatch batch){
        if(life <= 0){
            batch.draw(Resources.blackout, 0, 0);
            font.setColor(Color.RED);
            font.getData().setScale(2.0f);
            batch.draw(Resources.playAgainButton, 412, 300);
            font.getData().setScale(1.0f);
            font.setColor(Color.GREEN);
            font.draw(batch, "CLICK ANYWHERE", 437, 260);
        }

        font.setColor(Color.YELLOW);
        font.draw(batch, "Money: " + money, 5, 595);
        font.setColor(Color.PINK);
        font.draw(batch, "Wave: " + wave, 5, 575);
        font.setColor(Color.GREEN);
        font.draw(batch, "Life: " + life, 5, 555);

        if(msg){
            if(counter < 50){
                font.setColor(Color.YELLOW);
                font.getData().setScale(4.0f);
                font.draw(batch, "WAVE " + wave, 425, 300);
                font.getData().setScale(1.0f);
                counter++;
            } else if (counter >= 50) {
                counter = 0;
                msg = false;
            }
        }
    }
}
