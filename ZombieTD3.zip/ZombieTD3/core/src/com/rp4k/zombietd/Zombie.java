package com.rp4k.zombietd;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Rectangle;

public class Zombie {
    //Zombie attributes
    public Texture zombieTexture;
    public float xPos, yPos, width, height, speed;
    public boolean active;
    public int hp;

    //Zombie animation
    public int col, row;
    public Animation anim;
    public TextureRegion[] frames;
    public TextureRegion currFrame;
    public float frameTime;

    public Zombie(Texture ztex, float x, float y, float speed, int hp, int col, int row, int damage){
        zombieTexture = ztex;
        xPos = x;
        yPos = y;
        width = zombieTexture.getWidth() / col;
        height = zombieTexture.getHeight();
        this.speed = speed;
        active = true;
        this.hp = hp;
        damage = hp - damage;
        initAnimations(col, row);
    }

    public void draw(SpriteBatch batch){
        frameTime += Gdx.graphics.getDeltaTime();
        currFrame = (TextureRegion)anim.getKeyFrame(frameTime, true);
        batch.draw(currFrame, xPos - width / 2, yPos - height /2);
    }

    public void update(){
        xPos -= speed;
        if(xPos < -20){
            UI.life--;
            active = false;
        }
    }

    public Rectangle getRectangle(){
        return new Rectangle(xPos, yPos, width, height);
    }

    public void takeDamage(){
        if(hp-- < 0){
            active = false;
            UI.money += 5;
        }
    }

    public void initAnimations(int cool, int roow){
        row = roow;
        col = cool;

        TextureRegion[][] tempSheet = TextureRegion.split(zombieTexture,
                                            zombieTexture.getWidth() / col,
                                            zombieTexture.getHeight() / row);

        frames = new TextureRegion[row * col];

        int frameIndex = 0;

        for(int r = 0; r < row; r++){
            for(int c = 0; c < col; c++){
                frames[frameIndex++] = tempSheet[r][c];
            }
        }

        anim = new Animation(0.2f, frames);
    }
}
