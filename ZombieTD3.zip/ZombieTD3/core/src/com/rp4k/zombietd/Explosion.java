package com.rp4k.zombietd;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

public class Explosion {
    //Attributes
    public Texture explosionTexture;
    public float xPos, yPos, width, height;
    public boolean active;
    public int duration;

    //Animation Attributes
    public int col, row;
    public Animation anim;
    public TextureRegion[] frames;
    public TextureRegion currFrame;
    public float frameTime;

    public Explosion(Texture etex, float x, float y, int col, int row){
        explosionTexture = etex;
        xPos = x;
        yPos = y;
        width = explosionTexture.getWidth();
        height = explosionTexture.getHeight();
        this.col = col;
        this.row = row;
        active = true;
        duration = 10;
        initAnimations(col, row);
    }

    public void draw(SpriteBatch batch){
        frameTime += Gdx.graphics.getDeltaTime();
        currFrame = (TextureRegion)anim.getKeyFrame(frameTime, false);
        batch.draw(currFrame, xPos - width / 2, yPos - height / 2);
    }

    public void update(){
        if(duration-- < 0)
            active = false;
    }

    public void initAnimations(int cool, int roow){
        row = roow;
        col = cool;

        TextureRegion[][] tempSheet = TextureRegion.split(explosionTexture,
                explosionTexture.getWidth() / col,
                explosionTexture.getHeight() / row);

        frames = new TextureRegion[row * col];

        int frameIndex = 0;

        for(int r = 0; r < row; r++){
            for(int c = 0; c < col; c++){
                frames[frameIndex++] = tempSheet[r][c];
            }
        }

        anim = new Animation(0.2f, frames);
    }
}
