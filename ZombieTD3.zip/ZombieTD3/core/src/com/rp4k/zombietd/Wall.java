package com.rp4k.zombietd;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;

public class Wall {
    public float xPos, yPos, width, height;
    public Texture wallTexture;
    public boolean active;
    public int durability;

    public Wall(float x, float y){
        wallTexture = Resources.wallTexture;
        xPos = x;
        yPos = y;
        width = wallTexture.getWidth();
        height = wallTexture.getHeight();
        active = true;
        durability = 5;
    }

    public void draw(SpriteBatch batch){
        batch.draw(wallTexture, xPos, yPos);
    }

    public Rectangle getRectangle(){
        return new Rectangle(xPos, yPos, width, height);
    }

    public void takeDamage(int damage){
        durability -= damage;
        if(durability < 0)
            active = false;
    }
}
