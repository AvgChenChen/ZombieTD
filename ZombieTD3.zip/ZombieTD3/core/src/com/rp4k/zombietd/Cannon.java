package com.rp4k.zombietd;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Rectangle;

import java.util.Arrays;


public class Cannon {
    public Sprite cannonSprite;
    public float xPos, yPos, width, height, angle;
    public int fireDelay, counter;
    public String type;

    public int col, row;
    public Animation anim;
    public TextureRegion[] frames;
    public TextureRegion currFrame;
    public float frameTime;

    public Cannon(Texture btex, String type, float x, float y, int row, int col){
        switch(type){
            case "fire":
                cannonSprite = new Sprite(Resources.fireCannon);
                fireDelay = 30;
                break;
            case "super":
                cannonSprite = new Sprite(Resources.superCannon);
                fireDelay = 20;
                break;
            case "beam":
                cannonSprite = new Sprite(Resources.beamCannon);
                fireDelay = 35;
                break;
            case "crab":
                cannonSprite = new Sprite(Resources.crabCannon);
                fireDelay = 10;
                break;
            case "double":
                cannonSprite = new Sprite(Resources.doubleCannon);
                fireDelay = 40;
                break;
            case "mounted":
                cannonSprite = new Sprite(Resources.mountedCannon);
                fireDelay = 200;
                break;
            default:
                cannonSprite = new Sprite(Resources.cannon);
                fireDelay = 15;
                break;
        }
        this.type = type;
        width = Resources.cannon.getWidth();
        height = Resources.cannon.getHeight();
        xPos = lockToGrid(x - width / 2);
        yPos = lockToGrid(y - height / 2);
        cannonSprite.setPosition(xPos, yPos);
        angle = 0;
    }

    public void draw(SpriteBatch batch){
        cannonSprite.draw(batch);

    }

    public void update(){
        getAngle();
        cannonSprite.setRotation(angle);
        if(counter++ >= fireDelay) {
            fire();
            counter = 0;
        }
    }

    public void fire(){
        if(!ZombieTD.zombieList.isEmpty()){
            Texture bulletTexture = Resources.bulletTexture;
            switch(type){
                case "fire":
                    bulletTexture = Resources.fireBullet;
                    break;
                case "beam":
                    bulletTexture = Resources.beamCannonBullet;
                    break;
                case "super":
                    bulletTexture = Resources.superBullet;
                    break;
                case "crab":
                    bulletTexture = Resources.crabCannonBullet;
                    break;
                default:
                    bulletTexture = Resources.bulletTexture;
                    break;
            }
            if(type != "double") {
                Bullet b = new Bullet(bulletTexture, xPos + width / 2, yPos + height / 2);
                switch(type){
                    case "fire":
                        b.damage = 10;
                        break;
                    default:
                        b.damage = 1;
                        break;
                }
                ZombieTD.bulletList.add(b);
            } else {
                ZombieTD.bulletList.add(new Bullet(bulletTexture, xPos + width / 4, yPos + height / 4));
                ZombieTD.bulletList.add(new Bullet(bulletTexture, xPos + width / 4 * 3, yPos + height / 4 * 3));
            }

        }
    }

    public void getAngle(){
        if(!ZombieTD.zombieList.isEmpty()){
            float[] da = new float[ZombieTD.zombieList.size()]; // difference array
            for(int i = 0; i < ZombieTD.zombieList.size(); i++){
                da[i] = Math.abs(xPos - ZombieTD.zombieList.get(i).xPos) + Math.abs(yPos - ZombieTD.zombieList.get(i).yPos);
            }
            Arrays.sort(da);
            float xZ, yZ, angle;
            xZ = 0;
            yZ = 0;

            for(int i = 0; i < ZombieTD.zombieList.size(); i++){
                if(da[0] == Math.abs(xPos - ZombieTD.zombieList.get(i).xPos) + Math.abs(yPos - ZombieTD.zombieList.get(i).yPos)){
                    xZ = ZombieTD.zombieList.get(i).xPos;
                    yZ = ZombieTD.zombieList.get(i).yPos;
                }
            }

            angle = (float) Math.atan((yPos - yZ) / (xPos - xZ));
            if(xPos >= xZ)
                angle += Math.PI;
            this.angle = (float) Math.toDegrees(angle);
        }
    }

    public float lockToGrid(float pos){
        return ((int)(pos+25)/50) * 50;
    }

    public Rectangle getRectangle(){
        return new Rectangle(xPos, yPos, width, height);
    }

    public void initAnimations(int cool, int roow){
         row = roow;
         col = cool;

        TextureRegion[][] tempSheet = TextureRegion.split(Resources.cannon,
                Resources.cannon.getWidth() / col,
                Resources.cannon.getHeight() / row);

        frames = new TextureRegion[row * col];

        int frameIndex = 0;

        for(int r = 0; r < row; r++){
            for(int c = 0; c < col; c++){
                frames[frameIndex++] = tempSheet[r][c];
            }
        }

        anim = new Animation(0.2f, frames);
    }

}
