package com.rp4k.zombietd;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Texture;

public class Resources {
    //Backgrounds
    public static Texture bgTexture = new Texture(Gdx.files.internal("Grassybackground.png"));
    public static Texture dgTexture = new Texture(Gdx.files.internal("DungeonBackground.png"));

    //Cannons
    public static Texture cannon = new Texture(Gdx.files.internal("Cannon.png"));
    public static Texture fireCannon = new Texture(Gdx.files.internal("Firecannon.png"));
    public static Texture evilFlappyCannon = new Texture(Gdx.files.internal("EvilFlappyCannon.png"));
    public static Texture superCannon = new Texture(Gdx.files.internal("SuperCannon.png"));
    public static Texture nvidia = new Texture(Gdx.files.internal("nvidia.gif"));
    public static Texture amazon = new Texture(Gdx.files.internal("amazon.jpg"));
    public static Texture asus = new Texture(Gdx.files.internal("asus.jpg"));
    public static Texture beamCannon = new Texture(Gdx.files.internal("BeamCannon.png"));
    public static Texture crabCannon = new Texture(Gdx.files.internal("CrabCannon.png"));
    public static Texture doubleCannon = new Texture(Gdx.files.internal("doubleCannon.png"));
    public static Texture mountedCannon = new Texture(Gdx.files.internal("mountedCannon.png"));

    //Zombies
    public static Texture zombieTexture = new Texture(Gdx.files.internal("Zombie.png"));
    public static Texture animatedZombieTexture = new Texture(Gdx.files.internal("Zombies.png"));
    public static Texture difZombieTexture = new Texture(Gdx.files.internal("DifZombies.png"));
    public static Texture fastZombieTexture = new Texture(Gdx.files.internal("Fastzombies.png"));
    public static Texture riotZombieTexture = new Texture(Gdx.files.internal("riotzombie.png"));
    public static Texture riotZombieBIGTexture = new Texture(Gdx.files.internal("riotzombieBIG.png"));
    public static Texture speedyZombieTexture = new Texture(Gdx.files.internal("speedy_zombie.png"));
    public static Texture rtx3080 = new Texture(Gdx.files.internal("rtx3080.gif"));
    public static Texture bill = new Texture(Gdx.files.internal("bill.png"));

    //Bullets
    public static Texture bulletTexture = new Texture(Gdx.files.internal("Bullet.png"));
    public static Texture crabCannonBullet = new Texture(Gdx.files.internal("CrabCannonBullet.png"));
    public static Texture flappyBulletTexture = new Texture(Gdx.files.internal("FlappyBullet.png"));
    public static Texture beamCannonBullet = new Texture(Gdx.files.internal("BeamCannonBullet.png"));
    public static Texture fireBullet = new Texture(Gdx.files.internal("firebullet.png"));
    public static Texture superBullet = new Texture(Gdx.files.internal("superbullet.png"));


    //Icons + UI
        //Icons
        public static Texture cannonIcon = new Texture(Gdx.files.internal("CannonIcon.png"));
        public static Texture fireCannonIcon = new Texture(Gdx.files.internal("FireCannonIcon.png"));
        public static Texture playAgainButton = new Texture(Gdx.files.internal("PlayAgain.png"));
        public static Texture superCannonIcon = new Texture(Gdx.files.internal("SuperCannonIcon.png"));
        public static Texture beamCannonIcon = new Texture(Gdx.files.internal("BeamCannonIcon.png"));
        public static Texture crabCannonIcon = new Texture(Gdx.files.internal("CrabCannonIcon.png"));
        public static Texture doubleCannonIcon = new Texture(Gdx.files.internal("doubleCannonIcon.png"));
        public static Texture wallIcon = new Texture(Gdx.files.internal("WallIcon.png"));
        public static Texture mountedCannonIcon = new Texture(Gdx.files.internal("mountedCannonIcon.png"));
    //UI
        public static Texture blackout = new Texture(Gdx.files.internal("blackout.png"));
        public static Texture wallTexture = new Texture(Gdx.files.internal("Wall.png"));
        public static Texture border = new Texture(Gdx.files.internal("border.png"));
        public static Texture locked = new Texture(Gdx.files.internal("locked.png"));
        public static Texture border1 = new Texture(Gdx.files.internal("border1.png"));


    //Explosions
    public static Texture basicExplosion = new Texture(Gdx.files.internal("Explosion.png"));
    public static Texture zombieBoom = new Texture(Gdx.files.internal("zombie_boom.png"));
    public static Texture zombieDeath = new Texture(Gdx.files.internal("zombie_death.png"));

    //Audio
    public static Sound bulletFire = Gdx.audio.newSound(Gdx.files.internal("Bullet.mp3"));
    public static Sound FirebulletFire = Gdx.audio.newSound(Gdx.files.internal("FireBullet.mp3"));


    //For fun
    public static Texture hat = new Texture(Gdx.files.internal("hat_bye_bye.png"));


}
